package com.sitepoint.example03; // Change as appropriate

/**
 * Created by echessa on 10/14/15.
 */
public class Constants {

    private Constants(){

    }

    public static final String PACKAGE_NAME = "com.sitepoint.activityexample";

    public static final String STRING_ACTION = PACKAGE_NAME + ".STRING_ACTION";

    public static final String STRING_EXTRA = PACKAGE_NAME + ".STRING_EXTRA";

}