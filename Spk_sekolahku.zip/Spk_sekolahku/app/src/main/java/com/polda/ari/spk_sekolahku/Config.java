package com.polda.ari.spk_sekolahku;

public class Config {
    public static String URL_REGIS = "http://pstiubl.com/api_spk/regis.php";
    public static String URL_SEKOLAH = "http://pstiubl.com/api_spk/dt_sekolah.php";

    public static String TAG_EMAIL = "email";
    public static String TAG_PASS = "pass";
    public static String TAG_NAMA= "nama";

    public static String TAG_STATUS= "status_sek";
    public static String TAG_NAMASEK= "nama_sek";


}
