package com.polda.ari.spk_sekolahku;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class Frm_dt_sekolah extends AppCompatActivity {
ListView listView;
String JSON_STRING;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frm_dt_sekolah);
        listView = (ListView) findViewById(R.id.listViewSek);
        final Intent intent = getIntent();
        intent.getStringExtra(Frm_pilih.jenis);
        getJSON();
    }


    private void showDetail(){
        //Toast.makeText(getApplication(),"Data Dokter "+json,Toast.LENGTH_LONG).show();
        ArrayList<HashMap<String, String>> list = new ArrayList<HashMap<String, String>>();
        try {
            JSONObject jsonObject = new JSONObject(JSON_STRING);
            JSONArray result = jsonObject.getJSONArray("result");

            for(int i = 0; i<result.length(); i++){
                JSONObject c = result.getJSONObject(i);

                String status  = c.getString(Config.TAG_STATUS);
                String nama_sek  = c.getString(Config.TAG_NAMASEK);

                HashMap<String, String> employees = new HashMap<>();
                employees.put(Config.TAG_STATUS, status);
                employees.put(Config.TAG_NAMASEK, nama_sek);
                list.add(employees);
                //Toast.makeText(getApplication(),"Data "+hari,Toast.LENGTH_LONG).show();
            }

        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(getApplication(),"Data "+e,Toast.LENGTH_LONG).show();
        }

        ListAdapter adapter = new SimpleAdapter(
                Frm_dt_sekolah.this, list, R.layout.list_sekolah,
                new String[]{Config.TAG_STATUS,Config.TAG_NAMASEK},
                new int[]{R.id.txt_nama_sek, R.id.txt_status});

        listView.setAdapter(adapter);


    }


    private void getJSON(){
        class GetJSON extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(Frm_dt_sekolah.this,"Mengambil Data","Mohon Tunggu...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                JSON_STRING=s;
                showDetail();
                //Toast.makeText(getApplication(),"Data "+s,Toast.LENGTH_LONG).show();
            }

            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequest(Config.URL_SEKOLAH);
                return s;
            }
        }
        GetJSON gj = new GetJSON();
        gj.execute();
    }

}
