package com.polda.ari.spk_sekolahku;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class Frm_menu extends AppCompatActivity {
ImageButton btn_skl,btn_tuju,btn_ab,btn_log;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frm_menu);
        btn_skl = (ImageButton) findViewById(R.id.btn_sekolah);
        btn_tuju = (ImageButton) findViewById(R.id.btn_tujuan);
        btn_ab = (ImageButton) findViewById(R.id.btn_about);
        btn_log = (ImageButton) findViewById(R.id.btn_logout);

        btn_skl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Frm_menu.this, Frm_dt_sekolah.class);
                startActivity(intent);
            }
        });
    }
}
