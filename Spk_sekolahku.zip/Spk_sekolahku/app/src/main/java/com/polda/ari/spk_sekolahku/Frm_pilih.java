package com.polda.ari.spk_sekolahku;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Frm_pilih extends AppCompatActivity {
ImageButton btn_sma,btn_smk;
    public static String jenis;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frm_pilih);
        btn_sma = (ImageButton) findViewById(R.id.btn_sma);
        btn_smk = (ImageButton) findViewById(R.id.btn_smk);

        btn_sma.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Frm_pilih.this,Frm_dt_sekolah.class);
                jenis = "SMA";
                intent.putExtra("SMA", jenis);
                finish();
                startActivity(intent);
            }
        });


        btn_smk.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Frm_pilih.this,Frm_dt_sekolah.class);
                jenis = "SMK";
                intent.putExtra("SMK", jenis);
                finish();
                startActivity(intent);
            }
        });

    }
}
