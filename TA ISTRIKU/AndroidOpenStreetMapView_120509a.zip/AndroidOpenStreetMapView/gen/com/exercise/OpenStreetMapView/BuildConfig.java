/** Automatically generated file. DO NOT MODIFY */
package com.exercise.OpenStreetMapView;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}